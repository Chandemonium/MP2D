#include<iostream>
#include<fstream>
#include<string>
#include<sstream>
#include<vector>
#include<stdio.h>
#include<stdlib.h>
#include<cmath>

using namespace std;

class Dispersion_Correction {
    private:
        Dispersion_Correction();
        ~Dispersion_Correction();

    double *CutoffRadii, *r0AB, *Coordination_Number, *Coordination_Number_step, *Coordination_Number_Deriv,*Coordination_Number_FD, *UCHF, *CKS, *GaussA_C6_CKS,*C6_CKS_deriv,*C6_CKS_FD, *d_E6_CKS, *modR_AB, *GaussA_C6_UCHF, *C6_UCHF_deriv, *C6_UCHF_FD, *d_E6_UCHF, *C8CKS, *C8CKS_deriv, *d_E8_CKS, *C8UCHF,  *C8UCHF_deriv, *d_E8_UCHF, *E6_CKS_coord_derivs, *E6_UCHF_coord_derivs, *E8_CKS_coord_derivs, *E8_UCHF_coord_derivs;
    double **RcovAB;
    int *Ref_Compounds;
    int C6_counter;
    int UCHF_counter;
    double a_one, a_two, rcut, width, s_8;
    vector<vector<double> > matrix_Grimme;
    vector<vector<double> > matrix_UCHF;

    public:


        // Instantiate the single instance of the CN class
        static Dispersion_Correction& dispersion_correction() {
            static Dispersion_Correction thedispersion_correction;
            return thedispersion_correction;
        }

        bool Gradient_U;
        bool Param_U;
        bool UCHF_U;
        bool CKS_U;
        bool w_U;
        bool rcut_U;
        bool TT_a1_U;
        bool TT_a2_U;
        bool s8_U;
        bool CKS_Coeffs;
        bool UCHF_Coeffs;


        double L_ij;
        double L_ij_step;
        double L_ij_deriv;
        double deriv_prefactor;
        double deriv_postfactor;

        // Variables for user defined inputs
        string Param;
        string UCHF_Path;
        string CKS_Path;
        string uchf_coeffs;
        string cks_coeffs;
        double Width;
        double Rcut;
        double TT_a1;
        double TT_a2;
        double s8;

        string Path;
        string GrimmePath;
        string UCHFPath;
        string CKSPATH;
        string UCHFPATH;

        // factorials used in the energy expressions
        //double factorial[7] = {1.0, 1.0, 2.0, 6.0, 24.0, 120.0, 720.0};

//        void Initialize(ifstream& infile);
        void Initialize(ifstream& infile, int argc, char* argv[]);
        void UseFunction();
        // Can I grab some of the parameters from the input file?
        void GetUserParameters(int argc, char* argv[]);
        void GetParameters(ifstream& infile);
        void GetCutoffRadii();
        void GetCovalentRadii();
        double *CalculateCN();
        double *CalculateCN_step();
        double *CalculateCN_derivative();
        double *CalculateCN_derivative_FD();
        void *GetNumberReferenceCompounds();
        void GetC6Coefficients();
        void GetCKSC6();
        void GetUCHFC6();
        double GetCKSEnergy();
        double GetCKSC8Energy();
        double GetUCHFEnergy();
        double GetUCHFC8Energy();
        void MP2DGet_DispersionCorrection();
        void GetGradient();
        
        void Rewind(ifstream& infile) {
        infile.clear();
        infile.seekg(0,ios::beg);
        }
        
        
};
