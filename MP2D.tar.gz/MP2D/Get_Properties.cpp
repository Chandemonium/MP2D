#include<iostream>
#include<string>
#include"Get_Properties.h"
#include<sstream>
#include<fstream>

//Need to initialize the Class Get_Properties, first create a constructor

//Constructor
Get_Properties::Get_Properties() :  Natoms_per_monomer(NULL), AtomicSymbols(NULL), 
AtomicNumbers(NULL), xyz(NULL), symbols(NULL),
				    atomic_number(NULL), r(NULL),Coords(NULL), Symbols(NULL), distance(NULL), other_distance(NULL), xyz_deriv(NULL), xyz_distances(NULL), r2_r4(NULL)
{
}


void Get_Properties::Initialize(ifstream &infile) {

    AllAtoms = BeforeGetTotalNumberOfAtoms(infile);
    TotAtom = GetTotalNumberOfAtoms();
    GetCoordinatesDifferently(infile);
    MoveCoordinates();
    GetSymbols();
    CalculateDistancesDifferently();
    CoordinateDerivs();
    CoordinateDerivs_2();
    *GetAtomicNumber();
    *GetMultipoleExpectationValue();
   
}

//Destructor
Get_Properties::~Get_Properties() {

    delete [] Natoms_per_monomer;
    delete [] types;
    delete [] xyz;

    delete [] AtomicSymbols;
    delete [] AtomicNumbers;
    delete [] r2_r4;
    delete [] distance;
    delete [] other_distance;
    delete xyz_deriv;

}    

// This is the new GetTotalNumberOfAtoms where I try to get Atoms_Total by counting lines that have four strings
int Get_Properties::BeforeGetTotalNumberOfAtoms(ifstream& infile) {

    string line;
    Natoms_per_monomer = new int[1];
    Rewind(infile);
    int count = 0;
    while(getline(infile,line)) {
        count++;
    }
    count = count - 2;
    Natoms_per_monomer[0] = count;
    //int Atoms_Total = count;

       

    //return Atoms_Total;

    string line2;
    int Ntot = TotAtom;
    Rewind(infile);
    getline(infile,line2);
    string numberofatoms = line2;

    stringstream ATOMS(numberofatoms);
    ATOMS >> NumberOfAtoms;

    int Atoms_Total = NumberOfAtoms;
    return NumberOfAtoms;
    
}

int Get_Properties::GetTotalNumberOfAtoms() {
    int Atoms_Total = AllAtoms;
  
    return Atoms_Total;
}

//This is where I get the atom symbols and geometry coordinates
void Get_Properties::GetCoordinatesDifferently(ifstream& infile) {
    string line;
    
    int Ntot = TotAtom;
    symbols = new string[Ntot];
    xyz = new double[3*Ntot];

    Rewind(infile);

   
    int atom = 0;

    getline(infile,line);
    // Grab the number of atoms from the first line
    // Instead, I do this in BeforeGetTotalNumberOfAtoms
    getline(infile,line);
     
    // starting from the third line, loop through and store the coordinates
     for (int i=0; i< NumberOfAtoms; i++) {   
        infile >> symbols[atom];
        infile >> xyz[3*atom];
        infile >> xyz[3*atom+1];
        infile >> xyz[3*atom+2];
	atom++;
    }

}

// This function lets me send the Coordinates to the Dispersion_Correction class
double *Get_Properties::MoveCoordinates() {
    
    int Ntot = TotAtom;
    Coords = new double[3*Ntot];

    for (int i=0; i<Ntot; i++) {
        Coords[3*i] = xyz[3*i];
        Coords[3*i+1] = xyz[3*i+1];
        Coords[3*i+2] = xyz[3*i+2];
    }
    return Coords;

}

string *Get_Properties::GetSymbols() {
    
    int Ntot = TotAtom;
    Symbols = new string[Ntot];

    for (int i=0; i<Ntot; i++) {
        Symbols[i] = symbols[i];
    }
    return Symbols;
}

double **Get_Properties::CalculateDistancesDifferently() {
    
    int Ntot = TotAtom;
    double d_x, d_y, d_z;
    double x_deriv, y_deriv, z_deriv;
    distance = new double*[Ntot];
    for(int i=0; i < Ntot; i++) {
        distance[i] = new double[Ntot];
    }

    for (int i=0; i<Ntot;i++ ) {
        for (int j=0; j<Ntot; j++ ) {
            if (i==j) {
                d_x = 0.0;
                d_y = 0.0;
                d_z = 0.0;
            }
            else {
                d_x = xyz[3*i] - xyz[3*j];
                d_y = xyz[3*i+1] - xyz[3*j+1];
                d_z = xyz[3*i+2] - xyz[3*j+2];
            }
            distance[i][j] = sqrt(d_x*d_x + d_y*d_y + d_z*d_z);
        
            if (i==j) {
                x_deriv = 0.0;
                y_deriv = 0.0;
                z_deriv = 0.0;
            }
            else {
                x_deriv = d_x/distance[i][j];
             
                y_deriv = d_y/distance[i][j];
              
                z_deriv = d_z/distance[i][j];
              
            } 
            
        }
    }
    return distance;
}

double *Get_Properties::CoordinateDerivs() {
    
    int Ntot = TotAtom;

    int combinations = 0;
    for (int i=0;i<Ntot; i++) {
        combinations += i;
    } 

    double d_x, d_y, d_z;
    double x_deriv, y_deriv, z_deriv;
    int index = -1;

    other_distance = new double*[Ntot];
    xyz_deriv = new double[3*combinations];
    for(int i=0; i < Ntot; i++) {
        other_distance[i] = new double[Ntot];
    }

    for (int i=0; i<Ntot;i++ ) {
      
        for (int j=i+1; j<Ntot; j++ ) {
            index+=3;
      
            d_x = xyz[3*i] - xyz[3*j];
          
            d_y = xyz[3*i+1] - xyz[3*j+1];
         
            d_z = xyz[3*i+2] - xyz[3*j+2];
          
            other_distance[i][j] = sqrt(d_x*d_x + d_y*d_y + d_z*d_z);
         
            xyz_deriv[index-2] = d_x;

            xyz_deriv[index-1] = d_y;

            xyz_deriv[index] = d_z;
            
        }
    }
    for (int i=0; i < 3*combinations; i++) {
   
    }
    return xyz_deriv;
}

double **Get_Properties::CoordinateDerivs_2() {
    
    int Ntot = TotAtom;
    double d_x, d_y, d_z;
    double x_deriv, y_deriv, z_deriv;

    new_distance = new double*[Ntot];
    for(int i=0; i < Ntot; i++) {
        new_distance[i] = new double[Ntot];
    }
    
    xyz_distances = new double*[Ntot];
    for (int i=0; i < Ntot; i++) {
        xyz_distances[i] = new double[3*Ntot];
    }

    for (int i=0; i<Ntot;i++ ) {
        for (int j=0; j<Ntot; j++ ) {
            if (i==j) {
                d_x = 0.0;
                d_y = 0.0;
                d_z = 0.0;
            }
       
            else {
                d_x = xyz[3*i] - xyz[3*j];
                d_y = xyz[3*i+1] - xyz[3*j+1];
                d_z = xyz[3*i+2] - xyz[3*j+2];
            }
      
            new_distance[i][j] = sqrt(d_x*d_x + d_y*d_y + d_z*d_z);
            xyz_distances[i][3*j] = d_x;
       
            xyz_distances[i][3*j+1] = d_y;
       
            xyz_distances[i][3*j+2] = d_z;
        
            if (i==j) {
                x_deriv = 0.0;
                y_deriv = 0.0;
                z_deriv = 0.0;
            }
            else {
                x_deriv = d_x/distance[i][j];
             
                y_deriv = d_y/distance[i][j];
             
                z_deriv = d_z/distance[i][j];
             
            } 
            
        }
    }
    return xyz_distances;
}


// C++ does not allow you to return an entire array as an argument to a
// function. To get around this I defined this function as a pointer so
// that the returned argument is a pointer to the array. In this way I can
// access the elements of atomic_number[] from the Dispersion_Correction class.
int *Get_Properties::GetAtomicNumber() {
    
    int Ntot = TotAtom;
// atomic numbers of elements that we have UCHF coefficients for
// the index of a given element corresponds to its atomic number
    string AtomicSymbols[36] = {
        "XX",
        "H","XX",
        "XX","XX","B","C","N","O","F","Ne", // period 2
        "XX","XX","XX","XX","P","S","Cl","Ar", // period 3
        "XX","XX","XX","XX","XX","XX","XX","XX","XX","XX","XX","XX", // period 4
        "XX","XX","XX","XX","Br"}; // period 4
    
    int i, j, at_num = 0;

    atomic_number = new int[Ntot];
    // The array atomic_number is filled with the atomic numbers of each 
    // atom that appears in the input.
    int counter = 0;
    for (i=0;i<Ntot;i++) {
        for (j=0;j<36;j++) {
            if (symbols[i]==AtomicSymbols[j]) {
                at_num = j;
                atomic_number[i] = at_num;

                counter++;

            }
        }

    }
    if (counter!=Ntot) {
        cerr << "Calculation terminated, the input contains atoms that are not currently supported by MP2D. Please refer to README.txt." << endl;
        exit(1);
    }

    // Here the returned argument is a pointer to the array atomic_number[]
    return atomic_number;
}

double *Get_Properties::GetMultipoleExpectationValue() {
    
    int Ntot = TotAtom;

    double MultipoleExpectationValues[36] = { 0.0, 8.0589, 0.0, 0.0, 0.0, 11.8799, 7.8715, 5.5588, 4.7566, 3.8025
,3.1036, 0.0, 0.0, 0.0, 0.0, 9.5361, 8.1652, 6.7463, 5.6004, 0.0 ,0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 7.1251};

    int i, j;
    r2_r4 = new double[Ntot]; 

    for (int i=0;i<Ntot;i++) {
    
        r2_r4[i] = MultipoleExpectationValues[atomic_number[i]];
   
    }
    return r2_r4;
} 

